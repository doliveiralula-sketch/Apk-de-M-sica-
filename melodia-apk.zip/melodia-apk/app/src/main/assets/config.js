// Para a tag "Dono" aparecer no SEU perfil, coloque aqui o e-mail da sua conta no app.
// Exemplo: window.OWNER_EMAIL = "voce@email.com";
window.OWNER_EMAIL = "";
