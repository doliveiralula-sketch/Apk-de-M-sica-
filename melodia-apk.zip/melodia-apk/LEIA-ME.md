# Melodia: como gerar o APK (sem instalar nada)

O GitHub compila o APK para você, de graça, em cerca de 5 minutos. É bem mais fácil no computador.

1. Crie uma conta grátis em github.com e um repositório novo chamado "melodia" (marque **Private**).
2. Descompacte este zip. No repositório, clique em **Add file > Upload files** e arraste TODO o conteúdo da pasta, inclusive a pasta oculta `.github` (no Mac: Cmd+Shift+. mostra pastas ocultas). Clique em **Commit changes**.
   - Se a `.github` não subir: **Add file > Create new file**, digite o nome `.github/workflows/build.yml` e cole o conteúdo de `WORKFLOW.txt`.
3. Abra a aba **Actions**. O "Build APK" roda sozinho (ou use **Run workflow**). Espere ficar verde.
4. Clique na execução concluída, role até **Artifacts** e baixe **Melodia-APK**. Dentro do zip está o `app-release.apk`.
5. Passe o APK para o celular e abra. O Android vai pedir para permitir "instalar apps desconhecidos".

## Tag "Dono"
Edite `app/src/main/assets/config.js` no GitHub (ícone de lápis) e coloque o e-mail da sua conta no app. Ao salvar, um novo APK é gerado e atualiza o app sem perder seus dados.

## Observações
- O app usa o catálogo Audius para busca e streaming; precisa de internet.
- O APK é assinado com a chave `app/melodia.keystore`. Mantenha o repositório privado.
